import random
import time

print("Roblox gift card generator, created by: bunni~#0001")

results = random.randrange(1000000000, 9999999999)
print(results)

v = 1
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))

h = int(input("Want More? (press 1 for more) "))
if h == v:
  print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
h = int(input("Want More? (press 1 for more) "))
if h == v:
  print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
h = int(input("Want More? (press 1 for more) "))
if h == v:
  print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
h = int(input("Want More? (press 1 for more) "))
if h == v:
  print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))

h = int(input("Want More? (press 1 for more) "))
if h == v:
  print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))

h = int(input("Want More? (press 1 for more) "))
if h == v:
  print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))

h = int(input("Want More? (press 1 for more) "))
if h == v:
  print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))

h = int(input("Want More? (press 1 for more) "))
if h == v:
  print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))
print(random.randrange(1000000000, 9999999999))




str(input(" "))